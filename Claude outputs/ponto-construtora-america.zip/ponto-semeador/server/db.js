'use strict';

const { Pool } = require('pg');
const config = require('./config');
const { hashPassword } = require('./auth');

if (!config.databaseUrl) {
  console.error('----------------------------------------------------');
  console.error('ERRO: a variável de ambiente DATABASE_URL não foi definida.');
  console.error('Configure DATABASE_URL com a connection string do seu banco');
  console.error('Postgres (ex.: criado gratuitamente em https://neon.tech) antes');
  console.error('de iniciar o servidor. Veja o README para o passo a passo.');
  console.error('----------------------------------------------------');
  process.exit(1);
}

// Provedores gratuitos de Postgres (Neon, Supabase, etc.) exigem conexão via
// TLS. rejectUnauthorized:false evita problemas com a cadeia de certificados
// intermediária desses provedores; não é necessário (nem correto) exigir TLS
// para um Postgres local de desenvolvimento.
const usaSslLocal = /localhost|127\.0\.0\.1/.test(config.databaseUrl);

const pool = new Pool({
  connectionString: config.databaseUrl,
  ssl: usaSslLocal ? false : { rejectUnauthorized: false },
});

pool.on('error', (err) => {
  console.error('Erro inesperado numa conexão ociosa do pool do Postgres:', err);
});

// --- Migração leve: adiciona colunas novas em bancos já existentes, sem apagar dados ---
async function colunaExiste(tabela, coluna) {
  const { rows } = await pool.query(
    'SELECT 1 FROM information_schema.columns WHERE table_name = $1 AND column_name = $2',
    [tabela, coluna]
  );
  return rows.length > 0;
}

// Gera um "login" curto (ex.: primeiro nome) a partir do nome completo, sem
// acentos/espaços, para servir como identificador de acesso mais fácil que o
// e-mail. Usado tanto no seed do admin quanto na migração de contas antigas.
function slugFromNome(nome) {
  const primeiro = String(nome || '').trim().split(/\s+/)[0] || 'usuario';
  const semAcento = primeiro.normalize('NFD').replace(/[\u0300-\u036f]/g, '');
  const limpo = semAcento.toLowerCase().replace(/[^a-z0-9]/g, '');
  return limpo || 'usuario';
}

async function criarSchema() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS funcionarios (
      id SERIAL PRIMARY KEY,
      nome TEXT NOT NULL,
      email TEXT NOT NULL UNIQUE,
      login TEXT,
      senha_hash TEXT NOT NULL,
      cargo TEXT DEFAULT '',
      is_admin BOOLEAN NOT NULL DEFAULT FALSE,
      ativo BOOLEAN NOT NULL DEFAULT TRUE,
      jornada_entrada TEXT NOT NULL DEFAULT '08:00',
      jornada_saida TEXT NOT NULL DEFAULT '18:00',
      carga_horaria_diaria_minutos INTEGER NOT NULL DEFAULT 480,
      tolerancia_minutos INTEGER NOT NULL DEFAULT 10,
      dias_trabalho TEXT NOT NULL DEFAULT '1,2,3,4,5',
      verificar_atraso BOOLEAN NOT NULL DEFAULT TRUE,
      verificar_saida_antecipada BOOLEAN NOT NULL DEFAULT TRUE,
      tem_intervalo BOOLEAN NOT NULL DEFAULT TRUE,
      tipo_escala TEXT NOT NULL DEFAULT 'semanal',
      escala_data_referencia TEXT,
      horario_personalizado_semana BOOLEAN NOT NULL DEFAULT FALSE,
      horarios_semana JSONB,
      criado_em TIMESTAMPTZ NOT NULL DEFAULT now()
    );
  `);

  if (!(await colunaExiste('funcionarios', 'verificar_atraso'))) {
    await pool.query('ALTER TABLE funcionarios ADD COLUMN verificar_atraso BOOLEAN NOT NULL DEFAULT TRUE');
  }
  if (!(await colunaExiste('funcionarios', 'verificar_saida_antecipada'))) {
    await pool.query('ALTER TABLE funcionarios ADD COLUMN verificar_saida_antecipada BOOLEAN NOT NULL DEFAULT TRUE');
  }
  if (!(await colunaExiste('funcionarios', 'login'))) {
    await pool.query('ALTER TABLE funcionarios ADD COLUMN login TEXT');
  }
  if (!(await colunaExiste('funcionarios', 'tem_intervalo'))) {
    await pool.query('ALTER TABLE funcionarios ADD COLUMN tem_intervalo BOOLEAN NOT NULL DEFAULT TRUE');
  }
  if (!(await colunaExiste('funcionarios', 'tipo_escala'))) {
    await pool.query("ALTER TABLE funcionarios ADD COLUMN tipo_escala TEXT NOT NULL DEFAULT 'semanal'");
  }
  if (!(await colunaExiste('funcionarios', 'escala_data_referencia'))) {
    await pool.query('ALTER TABLE funcionarios ADD COLUMN escala_data_referencia TEXT');
  }
  if (!(await colunaExiste('funcionarios', 'horario_personalizado_semana'))) {
    await pool.query('ALTER TABLE funcionarios ADD COLUMN horario_personalizado_semana BOOLEAN NOT NULL DEFAULT FALSE');
  }
  if (!(await colunaExiste('funcionarios', 'horarios_semana'))) {
    await pool.query('ALTER TABLE funcionarios ADD COLUMN horarios_semana JSONB');
  }

  // Preenche o "login" para contas criadas antes dessa versão (que só tinham
  // e-mail). Gera a partir do primeiro nome, evitando colisão com logins já
  // existentes.
  const { rows: semLogin } = await pool.query(
    'SELECT id, nome FROM funcionarios WHERE login IS NULL ORDER BY id ASC'
  );
  if (semLogin.length) {
    const { rows: existentes } = await pool.query('SELECT login FROM funcionarios WHERE login IS NOT NULL');
    const loginsUsados = new Set(existentes.map((r) => r.login));
    for (const row of semLogin) {
      const base = slugFromNome(row.nome);
      let candidato = base;
      let sufixo = 2;
      while (loginsUsados.has(candidato)) {
        candidato = `${base}${sufixo}`;
        sufixo += 1;
      }
      loginsUsados.add(candidato);
      await pool.query('UPDATE funcionarios SET login = $1 WHERE id = $2', [candidato, row.id]);
    }
  }

  // Garante unicidade do login daqui pra frente (idempotente a cada subida).
  await pool.query('CREATE UNIQUE INDEX IF NOT EXISTS idx_funcionarios_login ON funcionarios (login)');

  await pool.query(`
    CREATE TABLE IF NOT EXISTS registros_ponto (
      id SERIAL PRIMARY KEY,
      funcionario_id INTEGER NOT NULL REFERENCES funcionarios(id) ON DELETE CASCADE,
      tipo TEXT NOT NULL CHECK (tipo IN ('entrada','saida_intervalo','retorno_intervalo','saida')),
      data_hora_utc TEXT NOT NULL,
      observacao TEXT DEFAULT '',
      editado_por_admin BOOLEAN NOT NULL DEFAULT FALSE,
      criado_em TIMESTAMPTZ NOT NULL DEFAULT now()
    );
  `);

  await pool.query(`
    CREATE INDEX IF NOT EXISTS idx_registros_funcionario_data
    ON registros_ponto (funcionario_id, data_hora_utc);
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS justificativas (
      id SERIAL PRIMARY KEY,
      funcionario_id INTEGER NOT NULL REFERENCES funcionarios(id) ON DELETE CASCADE,
      data_referencia TEXT NOT NULL,
      tipo TEXT NOT NULL DEFAULT 'outro',
      descricao TEXT NOT NULL,
      criado_em TIMESTAMPTZ NOT NULL DEFAULT now()
    );
  `);

  await pool.query(`
    CREATE INDEX IF NOT EXISTS idx_justificativas_funcionario
    ON justificativas (funcionario_id, data_referencia DESC);
  `);

  // Calendário único de feriados, válido pra todos os colaboradores. Num dia
  // marcado como feriado, a meta de horas vira zero (como um dia de folga) e
  // tudo que for trabalhado conta como hora extra — ver configDoDia() em
  // server/utils/relatorioUtils.js.
  await pool.query(`
    CREATE TABLE IF NOT EXISTS feriados (
      id SERIAL PRIMARY KEY,
      data TEXT NOT NULL UNIQUE,
      descricao TEXT NOT NULL DEFAULT '',
      criado_em TIMESTAMPTZ NOT NULL DEFAULT now()
    );
  `);
}

// --- Seed do administrador padrão, caso ainda não exista nenhum usuário ---
async function seedAdmin() {
  const { rows } = await pool.query('SELECT COUNT(*)::int AS total FROM funcionarios');
  if (rows[0].total > 0) return;
  const { nome, email, senha } = config.adminSeed;
  const senha_hash = hashPassword(senha);
  const login = slugFromNome(nome);
  await pool.query(
    `INSERT INTO funcionarios
      (nome, email, login, senha_hash, cargo, is_admin, ativo, jornada_entrada, jornada_saida, carga_horaria_diaria_minutos, tolerancia_minutos, dias_trabalho)
     VALUES ($1, $2, $3, $4, $5, TRUE, TRUE, '08:00', '18:00', 480, 10, '1,2,3,4,5')`,
    [nome, email, login, senha_hash, 'Administrador']
  );
  console.log('----------------------------------------------------');
  console.log('Usuário administrador criado automaticamente:');
  console.log('  Login : ' + login);
  console.log('  E-mail: ' + email);
  console.log('  Senha : ' + senha);
  console.log('  (troque a senha assim que possível em "Meu perfil")');
  console.log('----------------------------------------------------');
}

// initDb() é chamada uma vez, na subida do servidor (ver server.js), antes de
// aceitar requisições. É seguro chamá-la mais de uma vez (idempotente).
let initPromise = null;
function initDb() {
  if (!initPromise) {
    initPromise = (async () => {
      await criarSchema();
      await seedAdmin();
    })().catch((err) => {
      initPromise = null; // permite tentar novamente numa próxima chamada
      throw err;
    });
  }
  return initPromise;
}

module.exports = { pool, initDb };
